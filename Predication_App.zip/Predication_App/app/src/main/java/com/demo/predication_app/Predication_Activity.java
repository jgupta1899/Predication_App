package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Predication_Activity extends AppCompatActivity {


    RecyclerView recycler;
    Context c;
    ProgressDialog progressDialog;

    private List<String> rest_name=new ArrayList<>();
    private List<String> rest_type=new ArrayList<>();
    private List<String> loc=new ArrayList<>();
    private List<String> dine_rating=new ArrayList<>();
    private List<String> cost=new ArrayList<>();
    private List<String> liked=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predication);

        recycler=findViewById(R.id.predict);


        if (Home.word.equals("cafe"))
        {
            Log.e("Cafe_data2","enter inside cafe");
            try {
                JSONObject jsonObj = new JSONObject(MainActivity.getcafe);
                JSONArray peoples = jsonObj.getJSONArray("result");
                Log.e("Cafe_data3","enter inside cafe");

                for (int i = 0; i < peoples.length(); i++)
                {
                    Log.e("Cafe_data4","enter inside cafe");


                    JSONObject  c = peoples.getJSONObject(i);
                    Log.e("Cafe_data5",""+c.getString("rest_name"));
                    rest_name.add(c.getString("rest_name"));
                    rest_type.add(c.getString("rest_type"));
                    loc.add(c.getString("loc"));
                    dine_rating.add(c.getString("dine_rating"));
                    cost.add(c.getString("cost"));
                    liked.add(c.getString("liked"));


                }

                recycler.setLayoutManager(new LinearLayoutManager(this));
                AdapterCafe adapter=new AdapterCafe(rest_name,rest_type,loc,dine_rating,cost,liked,this);
                recycler.setAdapter(adapter);
            }
            catch (Exception Ex)
            {

            }
        }else if (Home.word.equals("apps"))
        {
            Log.e("Apps_data2","enter inside cafe");
            try {
                JSONObject jsonObj = new JSONObject(MainActivity.getapps);
                JSONArray peoples = jsonObj.getJSONArray("result");
                Log.e("Apps_data2","enter inside cafe");

                for (int i = 0; i < peoples.length(); i++)
                {
                    Log.e("Apps_data2","enter inside cafe");


                    JSONObject  c = peoples.getJSONObject(i);
                    Log.e("Apps_data2",""+c.getString("app_name"));
                    rest_name.add(c.getString("app_name"));
                    rest_type.add(c.getString("category"));
                    loc.add(c.getString("size"));
                    dine_rating.add(c.getString("rating"));
                    cost.add(c.getString("install"));
                    liked.add(c.getString("type"));


                }

                recycler.setLayoutManager(new LinearLayoutManager(this));
                AdapterCafe adapter=new AdapterCafe(rest_name,rest_type,loc,dine_rating,cost,liked,this);
                recycler.setAdapter(adapter);
            }
            catch (Exception Ex)
            {

            }
        }else if (Home.word.equals("movies"))
        {
            Log.e("Apps_data2","enter inside cafe");
            try {
                JSONObject jsonObj = new JSONObject(MainActivity.getmovies);
                JSONArray peoples = jsonObj.getJSONArray("result");
                Log.e("Apps_data2","enter inside cafe");

                for (int i = 0; i < peoples.length(); i++)
                {
                    Log.e("Apps_data2","enter inside cafe");


                    JSONObject  c = peoples.getJSONObject(i);
                    Log.e("Apps_data2",""+c.getString("title"));
                    rest_name.add(c.getString("title"));
                    rest_type.add(c.getString("type"));
                    loc.add(c.getString("descp"));
                    dine_rating.add(c.getString("release_year"));
                    cost.add(c.getString("rating"));
                    liked.add(c.getString("duration"));


                }

                recycler.setLayoutManager(new LinearLayoutManager(this));
                AdapterCafe adapter=new AdapterCafe(rest_name,rest_type,loc,dine_rating,cost,liked,this);
                recycler.setAdapter(adapter);
            }
            catch (Exception Ex)
            {

            }
        }


    }
}