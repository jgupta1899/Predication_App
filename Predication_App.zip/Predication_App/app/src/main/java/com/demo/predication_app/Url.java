package com.demo.predication_app;

public class Url {

    public static final String url = "https://recomapp.000webhostapp.com/";
}
