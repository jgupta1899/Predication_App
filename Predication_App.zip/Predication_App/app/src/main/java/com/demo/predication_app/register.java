package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class register extends AppCompatActivity {

    TextView log;
    RelativeLayout relativeLayout;
    Button reg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        log = findViewById(R.id.log);
        reg = findViewById(R.id.reg);
        relativeLayout = findViewById(R.id.rel);



        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar snackbar = Snackbar
                        .make(relativeLayout, "Server is not activated", Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        });

        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(register.this,Login.class);
                startActivity(i);
            }
        });
    }
}