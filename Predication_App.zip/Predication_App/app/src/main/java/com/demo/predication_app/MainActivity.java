package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static String getcafe,getapps,getmovies;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getcafe();
                getapps();
                getmovies();
                Intent i=new Intent(MainActivity.this,FirstScreen.class);
                startActivity(i);
                finish();
            }
        }, 3000);

    }


    public void getcafe(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, Url.url+"cafe.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getcafe = response;
                        Log.e("Cafe_data",""+response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


    public void getapps(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, Url.url+"apps.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getapps = response;
                        Log.e("App_data",""+response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }

    public void getmovies(){


        StringRequest stringRequest=new StringRequest(Request.Method.POST, Url.url+"movie.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        getmovies = response;
                        Log.e("App_data",""+response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_LONG).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("lang","hi");


                return params;
            }
        };{

        };


        VolleySingleton v= VolleySingleton.getInstance(this);
        RequestQueue mRequestQueue=v.getRequestQueue();
        mRequestQueue.getCache().clear();
        mRequestQueue.add(stringRequest);
    }


}