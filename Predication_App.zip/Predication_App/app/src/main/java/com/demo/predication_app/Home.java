package com.demo.predication_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Home extends AppCompatActivity {
    CardView cafe,hospital,app,movies,books;
    public static String word;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cafe =findViewById(R.id.lay1);
        hospital =findViewById(R.id.lay3);
        app =findViewById(R.id.lay4);
        movies =findViewById(R.id.lay5);
        books =findViewById(R.id.lay6);


        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "cafe";
                Intent i = new Intent(Home.this,Predication_Activity.class);
                startActivity(i);

            }
        });

        hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "apps";
                Intent i = new Intent(Home.this,Predication_Activity.class);
                startActivity(i);

            }
        });

        movies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                word = "movies";
                Intent i = new Intent(Home.this,Predication_Activity.class);
                startActivity(i);

            }
        });

        books.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }
}